<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('site_model');		
	}
		
	public function index(){
		$this->load->library('pagination');
		
		$config['base_url']		= site_url("site/index");
		$config['total_rows'] 	= $this->db->get('tbl_users')->num_rows();
		$config['per_page']		= 5;
		$config['uri_segment'] 	= 3;

		$this->pagination->initialize($config);
		
		$data['no'] = $this->uri->segment(3);
		$data['pagination'] = $this->pagination->create_links();
		$data['records'] = $this->site_model->get_userlist($this->uri->segment(3));
		
		$this->load->view('userlist_view',$data);
	}
	
	public function add(){
		$this->load->view('add_view');
	}
	
	public function create(){
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('txt_name','Name', 'trim|required');
		$this->form_validation->set_rules('txt_age','Age', 'trim|required|numeric');
		$this->form_validation->set_rules('txt_gender','Gender', 'trim|required');
		$this->form_validation->set_rules('txt_email','Email Address', 'trim|required|valid_email');
		$this->form_validation->set_rules('txt_contact','Contact Number', 'trim|required|numeric|min_length[7]|max_length[10]');
		$this->form_validation->set_rules('txt_city','City', 'trim|required');

		if($this->form_validation->run() == FALSE){
			$this->add();
		}else{
			$isCheck = $this->site_model->add_record();
			if($isCheck == 1){
				redirect('site');
			}else{
				$data['err_msg'] = 'Something went wrong, Please try again';
				$this->load->view('add_view', $data);
			}	
		}
	}

	public function edit(){
		$data['record'] = $this->site_model->get_record();
		$this->load->view('edit_view', $data);
	}
	
	public function update(){
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('txt_name','Name', 'trim|required');
		$this->form_validation->set_rules('txt_age','Age', 'trim|required|numeric');
		$this->form_validation->set_rules('txt_gender','Gender', 'trim|required');
		$this->form_validation->set_rules('txt_email','Email Address', 'trim|required|valid_email');
		$this->form_validation->set_rules('txt_contact','Contact Number', 'trim|required|numeric|min_length[7]|max_length[10]');
		$this->form_validation->set_rules('txt_city','City', 'trim|required');

		if($this->form_validation->run() == FALSE){
			$this->edit();
		}else{
			$isCheck = $this->site_model->update_record();
			if($isCheck == 1){
				redirect('site');
			}else{
				$data['err_msg'] = 'Something went wrong, Please try again';
				$this->load->view('edit_view', $data);
			}
		}
	}
	
	public function delete(){
		$isCheck = $this->site_model->delete_record();
		if($isCheck == 1){
			redirect('site');
		}else{
			$data['err_msg'] = 'Something went wrong, Please try again';
			$this->load->view('userlist_view', $data);
		}
	}
}