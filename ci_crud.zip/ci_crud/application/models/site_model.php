<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site_model extends CI_Model{

	public function get_userlist($offset = null){
		$this->db->order_by('cr_date','desc')->limit(5,$offset);
		$query = $this->db->get('tbl_users');

		$data = array();
		
		if($query->num_rows() > 0){
			$data = $query->result();
			return $data;
		}else{
			return $data;
		}
	}
	
	public function add_record(){
		
		$post_data = array(
			'name' 		=> $this->input->post('txt_name'),
			'age' 		=> $this->input->post('txt_age'),
			'gender' 	=> $this->input->post('txt_gender'),
			'email' 	=> $this->input->post('txt_email'),
			'contact_no'=> $this->input->post('txt_contact'),
			'city' 		=> $this->input->post('txt_city'),
			'cr_date' 		=> date('Y-m-d H:i:s'),
			'modified_date'	=> date('Y-m-d H:i:s')
		);
		
		$insert = $this->db->insert('tbl_users', $post_data);
		
		if($insert){
			return $data = 1;
		}else{
			return $data = 0;
		}
	}
	
	public function get_record(){
		$data = $this->db->where('id',$this->uri->segment(3))->get('tbl_users')->result();
		return $data;
	}
	
	public function update_record(){
		
		$post_data = array(
			'name' 		=> $this->input->post('txt_name'),
			'age' 		=> $this->input->post('txt_age'),
			'gender' 	=> $this->input->post('txt_gender'),
			'email' 	=> $this->input->post('txt_email'),
			'contact_no'=> $this->input->post('txt_contact'),
			'city' 		=> $this->input->post('txt_city'),
			'modified_date'	=> date('Y-m-d H:i:s')
		);
		$this->db->where('id', $this->input->post('hid_userid'));
		
		$update = $this->db->update('tbl_users', $post_data);
		
		if($update){
			return $data = 1;
		}else{
			return $data = 0;
		}
	}
	
	public function delete_record(){
		$this->db->where('id', $this->uri->segment(3));
		$delete = $this->db->delete('tbl_users');
		
		if($delete){
			return $data = 1;
		}else{
			return $data = 0;
		}
	}
}