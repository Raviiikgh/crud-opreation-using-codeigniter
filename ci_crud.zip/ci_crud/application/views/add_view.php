<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>CRUD OPERATION</title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
	</head>
<body>
	<div id="container_feild">
		<h1>Add Information</h1>
		<div id="body">
			<?php echo validation_errors('<p class="err">'); ?>
			
			<?php if(isset($err_msg)) : ?>
				<p class="err"> <?php echo $err_msg; ?></p>
			<?php endif; ?>
			
			<?php echo form_open('site/create','id="formAdd"'); ?>
			<?php 
				$inputName = array(
						'name' 	=> 'txt_name',
						'id' 	=> 'txt_name',
						'value' => set_value('txt_name', '')
					);
				$inputAge = array(
						'name' 	=> 'txt_age',
						'id' 	=> 'txt_age',
						'maxlength' => '3',
						'value' => set_value('txt_age', '')
					);
				$inputGender = array(
						''  	=> 'Select',
						'Male'  => 'Male',
						'Female'=> 'Female'
					);
				$inputEmail = array(
						'name' 	=> 'txt_email',
						'id' 	=> 'txt_email',
						'value' => set_value('txt_email', '')
					);
				$inputContact = array(
						'name' 	=> 'txt_contact',
						'id' 	=> 'txt_contact',
						'value' => set_value('txt_contact', '')
					);
				$inputCity = array(
						'name' 	=> 'txt_city',
						'id' 	=> 'txt_city',
						'value' => set_value('txt_city', '')
					);
				$inputSubmit = array(
						'name' 	=> 'txt_submit',
						'id' 	=> 'txt_submit',
						'value' => 'Submit'
					);
			?>
			<div><label> Name : </label> <?php echo form_input($inputName); ?></div>
			<div><label> Age : </label> <?php echo form_input($inputAge); ?></div>
			<div>
				<label> Gender : </label> 
				<?php echo form_dropdown('txt_gender', $inputGender, set_value('txt_gender','')); ?>
			</div>
			<div><label> Email Address : </label> <?php echo form_input($inputEmail); ?></div>
			<div><label> Contact Number : </label> <?php echo form_input($inputContact); ?></div>
			<div><label> City : </label> <?php echo form_input($inputCity); ?></div>
			<div>
				<label></label>
				<?php echo form_submit('submit','Submit'); ?>
			</div>
			<?php echo form_close(); ?>
		</div>
	</div>
</body>
</html>