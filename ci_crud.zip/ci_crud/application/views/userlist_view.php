<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>CRUD OPERATION</title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
	</head>
<body>
	<div id="container_list">
		<h1>Users List <?php echo anchor("/site/add","Add New","class='right'"); ?></h1>
		<?php $no = (isset($no)) ? $no+1 : 1; ?>
		<?php if(isset($err_msg)) : ?>
			<p class="err"> <?php echo $err_msg; ?></p>
		<?php endif; ?>
			
		<div id="body">
			<table cellpadding="10" cellspacing="7"> 
			<tr>
				<th>No# </th>
				<th>Name </th>
				<th>Age </th>
				<th>Gender </th>
				<th>Email Address </th>
				<th>Contact No </th>
				<th>City </th>
				<th>Created Date </th>
				<th>Modify Date </th>
				<th>Option </th>
			</tr>
			<?php if(count($records) > 0) : foreach ($records as $value): ?>
			<tr>
				<td><?php echo $no; ?></td>
				<td><?php echo $value->name; ?></td>
				<td><?php echo $value->age; ?></td>
				<td><?php echo $value->gender; ?></td>
				<td><?php echo $value->email; ?></td>
				<td><?php echo $value->contact_no; ?></td>
				<td><?php echo $value->city; ?></td>
				<td><?php echo date("d-m-Y", strtotime($value->cr_date)); ?></td>
				<td><?php echo date("d-m-Y", strtotime($value->modified_date)); ?></td>
				<td><?php echo anchor("/site/edit/$value->id","edit"); ?> | <?php echo anchor("/site/delete/$value->id","delete"); ?></td>
			</tr>
			<?php $no++; endforeach; ?>
			<?php else : ?>
				<tr align="center"><td colspan="10"> No Records Found.</td></tr>
			<?php endif; ?>	
			</table>
			<div id="pagination">
				<?php if($pagination){ ?>
					Pages : <?php echo $pagination; ?>
				<?php }	?>
			</div>
			<div class="footer">
				<p> Find more at <a href="http://github.com/raviiikgh" target="_blank">http://github.com/raviiikgh</a>  <span class="right">THANK YOU</span></p>
			</div>
		</div>	
	</div>	
</body>
</html>	